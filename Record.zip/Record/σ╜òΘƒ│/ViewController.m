//
//  ViewController.m
//  录音
//
//  Created by 杭州共联房地产 on 16/12/12.
//  Copyright © 2016年 杭州共联房地产. All rights reserved.
//

#import "ViewController.h"
#import <AVFoundation/AVFoundation.h>


@interface ViewController ()

@property(nonatomic,strong)AVAudioRecorder  *recorder;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    /*
     录音的基本四步:
     1.获取文件存放的位置,或者创建
     2.创建录音对象
     3.开始录音(当然在录音的时候我们会加入一些特效,去音质啥的)
     4.结束录音
     
     */
    NSString *path = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES)lastObject];//这个是个数组,选最后一个
    
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSArray *tempFileList = [[NSArray alloc] initWithArray:[fileManager contentsOfDirectoryAtPath:path error:nil]];
    NSLog(@"%@",tempFileList);
    
    
    /*document：该目录中的文件，在备份 App 时会被备份；升级的时候也可以保留；
     tmp：系统定期删除；
     library：忘记了，自己查查。
     caches：备份或者升级时，不会保留。不会被系统删除，需要手工删除不用的文件。
     
     NSString *homeDir = NSHomeDirectory();
     // 获取Documents目录路径
     NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
     NSString *docDir = [paths objectAtIndex:0];
     // 获取Caches目录路径  大文件的下载存放
     NSArray *paths = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES);
     NSString *cachesDir = [paths objectAtIndex:0];
     // 获取tmp目录路径
     NSString *tmpDir =  NSTemporaryDirectory();
     */
}


- (IBAction)begin:(id)sender {
    
    
    
    
    //1.获取沙盒路径
   NSString *path = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES)lastObject];//这个是个数组,选最后一个
  
//    NSFileManager *fileManager = [NSFileManager defaultManager];
//    NSArray *tempFileList = [[NSArray alloc] initWithArray:[fileManager contentsOfDirectoryAtPath:path error:nil]];
       //补充,为了保证应用的内存占用的问题,我们在录音的时候,在存储建造路径之前我们最好是去在沙盒哪个文件下建立一个文件,然后我们删除啊,移动啊啥的直接对文件来,在每次存储我们都要判断文件大小,太大我们就要删除它,在做的完美的我们就按照日期删

    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd-HH:mm:ss"];
    NSString *strDate = [dateFormatter stringFromDate:[NSDate date]];
    NSString *str = [NSString stringWithFormat:@"%@.MP3",strDate];
    path = [path stringByAppendingPathComponent:str];//这个是路径字符串的拼接,和操作其他的字符串不一样的不一样,同时我们为了录音每个文件不一样,所以我们可以将它的名字用日期来,记住一定要注明MP3(大写)格式不然保报错,同时中间不能有空格
    
    
   NSLog(@"%@",path);
    NSURL * url = [NSURL URLWithString:path];//根据路径字符串生成url
    
    NSDictionary *dic = [NSDictionary dictionary];
    NSError *error = nil;
    AVAudioRecorder * recorder= [[AVAudioRecorder alloc]initWithURL:url settings:dic error:&error];

   // AVAudioRecorder  *recorder= [[AVAudioRecorder alloc]initWithURL:@"路径url" settings:@"参数,一般我们传入的是字典,我们这个通过一些空间设置一些值保存到字典里传到这里" error:@"这个是错误显示"]; 注意这个对象我们要使用全局的变量和定位器一样,不然不能持久进行
    [recorder record];//开始录制,它又方法限制自己的录制时间录音时间,或者搞个长按手势即可;还可以暂停
    
    self.recorder  = recorder;
}

- (IBAction)stop:(id)sender {
    [self.recorder stop];//停止
}


//看是否插入耳机和麦克风等问题
- (BOOL)isHeadsetPluggedIn {
    
    
    UInt32 routeSize = sizeof(CFStringRef);
    CFStringRef route;
    OSStatus error =AudioSessionGetProperty (kAudioSessionProperty_AudioRoute,&routeSize,&route);
    
         /* Known values of route:
       
       　　* "Headset"
       
       　　* "Headphone"
       
       　　* "Speaker"
       
       　　* "SpeakerAndMicrophone"
       
       　　* "HeadphonesAndMicrophone"
       
       　　* "HeadsetInOut"
       
       　　* "ReceiverAndMicrophone"
       
       　　* "Lineout"
       
       　　*/
          if (!error && (route != NULL)) {
         NSString* routeStr = (__bridge NSString*)route;
         NSRange headphoneRange = [routeStr rangeOfString : @"Head"];
              
              NSLog(@"----%lu",(unsigned long)headphoneRange.location);
        if (headphoneRange.location != NSNotFound)
            return YES;}
        return NO;
    }

@end
