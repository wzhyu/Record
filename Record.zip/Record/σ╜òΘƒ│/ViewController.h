//
//  ViewController.h
//  录音
//
//  Created by 杭州共联房地产 on 16/12/12.
//  Copyright © 2016年 杭州共联房地产. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

